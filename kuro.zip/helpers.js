async function getAllParticipants(sock, jid) {
  const metadata = await sock.groupMetadata(jid);
  return metadata.participants || [];
}
module.exports = { getAllParticipants };