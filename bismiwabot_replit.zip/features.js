
async function handleCommand(text, from) {
  if (text === ".menu") {
    return "Menu:\n.ask [text]\n.summarize [text]\n.translate [text]\n.quiz\n.vocab";
  } else if (text.startsWith(".ask")) {
    const prompt = text.replace(".ask", "").trim();
    return "AI response to: " + prompt;
  } else if (text.startsWith(".summarize")) {
    return "Summarized: " + text.replace(".summarize", "").trim();
  } else if (text.startsWith(".translate")) {
    return "Translated: " + text.replace(".translate", "").trim();
  } else if (text.startsWith(".quiz")) {
    return "Quiz: What is 2 + 2?\nA) 3\nB) 4\nC) 5\nD) 6";
  } else if (text.startsWith(".vocab")) {
    return "Vocabulary Word: Benevolent\nMeaning: Well meaning and kindly.";
  } else {
    return null;
  }
}

module.exports = { handleCommand };
