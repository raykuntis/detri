
const express = require('express');
const makeWASocket = require('@whiskeysockets/baileys').default;
const { useMultiFileAuthState } = require('@whiskeysockets/baileys');
const fs = require('fs');
const { Boom } = require('@hapi/boom');
const qrcode = require('qrcode-terminal');
const { handleCommand } = require('./features');

const app = express();
const PORT = process.env.PORT || 3000;

app.get("/", (_, res) => res.send("Bot is running"));

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));

const startBot = async () => {
  const { state, saveCreds } = await useMultiFileAuthState('auth');
  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true
  });

  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const from = msg.key.remoteJid;
    const body = msg.message.conversation || msg.message.extendedTextMessage?.text || "";

    const response = await handleCommand(body.trim(), from, sock, msg);
    if (response) {
      await sock.sendMessage(from, response, { quoted: msg });
    }
  });
};

startBot();
