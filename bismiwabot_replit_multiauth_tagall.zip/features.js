
async function handleCommand(text, from, sock, msg) {
  if (text === ".menu") {
    return { text: "Menu:\n.ask [text]\n.summarize [text]\n.translate [text]\n.quiz\n.vocab\n.tagall" };
  } else if (text.startsWith(".ask")) {
    const prompt = text.replace(".ask", "").trim();
    return { text: "AI response to: " + prompt };
  } else if (text.startsWith(".summarize")) {
    return { text: "Summarized: " + text.replace(".summarize", "").trim() };
  } else if (text.startsWith(".translate")) {
    return { text: "Translated: " + text.replace(".translate", "").trim() };
  } else if (text === ".quiz") {
    return { text: "Quiz: What is 2 + 2?\nA) 3\nB) 4\nC) 5\nD) 6" };
  } else if (text === ".vocab") {
    return { text: "Vocabulary Word: Benevolent\nMeaning: Well meaning and kindly." };
  } else if (text === ".tagall") {
    const groupMetadata = await sock.groupMetadata(from);
    const participants = groupMetadata.participants.map(p => p.id);
    const mentions = participants;
    const textTag = participants.map(p => `@${p.split("@")[0]}`).join(" ");
    return { text: textTag, mentions };
  } else {
    return null;
  }
}

module.exports = { handleCommand };
